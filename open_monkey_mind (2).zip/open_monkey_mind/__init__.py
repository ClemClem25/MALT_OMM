"""Plugins to integrate OpenMonkeyMind into OpenSesame"""
